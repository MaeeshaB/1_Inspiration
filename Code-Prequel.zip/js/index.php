<?php
	echo "You dont't have a permissions to access this folder";
?>